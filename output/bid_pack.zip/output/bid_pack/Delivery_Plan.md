# Delivery Plan - IR/2025/TRD/33KV-CABLE/014

| Milestone | Percentage | Timeline from Award |
|---|---|---|
| Batch 1 | 40% | 8 weeks |
| Batch 2 | 40% | 12 weeks |
| Batch 3 | 20% | 16 weeks |