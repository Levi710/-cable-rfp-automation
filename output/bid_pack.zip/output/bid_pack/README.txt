BID PACK
========

Tender: IR/2025/TRD/33KV-CABLE/014 — Supply of 33 kV XLPE Underground Cables for Railway Traction - 250 KM

Included:
- BOQ.csv (rates and totals)
- Technical_Compliance.md
- Certificates_List.md
- Delivery_Plan.md
- ALTERNATE_SKU_NOTES.md
- QUALIFICATION_NEXT.md

Final Quote (all-in): Rs 362,513,000 (reference)

Note: Attach signed certificates and finalize on company letterhead before submission.
