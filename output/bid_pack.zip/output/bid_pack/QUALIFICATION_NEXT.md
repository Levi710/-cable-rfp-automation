# Qualification — Next Priorities

1) Indian Railways 33 kV — Qualified as next priority (fit: 33kV XLPE armored).
   Action: Prepare summary and pre-bid queries; reuse 33kV pack.

2) NTPC 11 kV — Keep warm (fit: OEM-XLPE-11KV-3C-35).
   Action: Keep datasheets & pricing ready; move when capacity available.
