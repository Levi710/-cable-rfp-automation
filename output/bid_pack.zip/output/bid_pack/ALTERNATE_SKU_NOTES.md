# Alternate SKU Notes

Primary offer: Polycab OEM-XLPE-33KV-3C-120.

Alternate for competitive positioning: HAVELLS-33KV-3C-120 (technical equivalence; price reference Rs 1,480/m).
