# Certificates List (Attach)

- CPRI Type Test Certificate (33 kV) — see data/test_certificates/CPRI_Type_Test_Certificate_Polycab_33kV.txt
- BIS License — see data/test_certificates/BIS_License_Polycab.txt
- ISO 9001:2015 — see data/test_certificates/ISO_9001_Certificate_Polycab.txt

Note: Replace placeholders with signed PDFs for submission.